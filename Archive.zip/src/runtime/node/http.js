import ES6Promise from 'es6-promise';
import fetch from 'node-fetch';

ES6Promise.polyfill();

export default fetch;