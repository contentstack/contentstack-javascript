export default fetch;

