import localStorage from 'localStorage';

export default localStorage;
