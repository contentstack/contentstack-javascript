const ContentstackRegion = {
    EU: "eu",
    US: "us",
    AZURE_NA: "azure-na"
};

export default ContentstackRegion;
//module.exports = ContentstackRegion;