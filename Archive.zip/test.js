'use strict';
const test  = require('./test/automation-script.js');
new test();
