# To test follow the steps

 1. make sure the host is set to "Contentstack-Host"

    npm test

# Contentstack Configuration

        Stack = Contentstack.Stack({
            "api_key": "",
            "delivery_token": "",
            "environment": ""
        });
    

# Run the tests

npm test (to write output to file just follow | tap-json > path-to-file/filename.json)